from main import *


if __name__ == '__main__':
    m = Model()
    m.prepare_images()
    m.train()
