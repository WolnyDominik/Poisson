# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poisson']

package_data = \
{'': ['*'], 'poisson': ['model/*', 'model/variables/*']}

install_requires = \
['Pillow>=8.1.0,<9.0.0',
 'opencv-python>=4.5.1,<5.0.0',
 'tensorflow>=2.3.1,<3.0.0']

setup_kwargs = {
    'name': 'poisson',
    'version': '1.0',
    'description': 'Projekt do filtrowania szumu o rozkładzie Poissona',
    'long_description': None,
    'author': 'Dominik Wolny',
    'author_email': 'wolny.dominik@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6.0,<3.9',
}


setup(**setup_kwargs)
